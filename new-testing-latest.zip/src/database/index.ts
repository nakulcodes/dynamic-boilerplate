export * from './base-entity.interface';
export * from './repository.interface';
export * from './base-repository.abstract';